blue\_st\_sdk.features package
==============================

Subpackages
-----------

.. toctree::

    blue_st_sdk.features.audio
    blue_st_sdk.features.standard_characteristics

Submodules
----------

blue\_st\_sdk.features.device\_timestamp\_feature module
--------------------------------------------------------

.. automodule:: blue_st_sdk.features.device_timestamp_feature
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__

blue\_st\_sdk.features.feature\_accelerometer module
----------------------------------------------------

.. automodule:: blue_st_sdk.features.feature_accelerometer
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__

blue\_st\_sdk.features.feature\_activity\_recognition module
------------------------------------------------------------

.. automodule:: blue_st_sdk.features.feature_activity_recognition
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__

blue\_st\_sdk.features.feature\_audio\_scene\_classification module
-------------------------------------------------------------------

.. automodule:: blue_st_sdk.features.feature_audio_scene_classification
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__

blue\_st\_sdk.features.feature\_gyroscope module
------------------------------------------------

.. automodule:: blue_st_sdk.features.feature_gyroscope
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__

blue\_st\_sdk.features.feature\_humidity module
-----------------------------------------------

.. automodule:: blue_st_sdk.features.feature_humidity
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__

blue\_st\_sdk.features.feature\_magnetometer module
---------------------------------------------------

.. automodule:: blue_st_sdk.features.feature_magnetometer
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__

blue\_st\_sdk.features.feature\_pressure module
-----------------------------------------------

.. automodule:: blue_st_sdk.features.feature_pressure
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__

blue\_st\_sdk.features.feature\_proximity module
------------------------------------------------

.. automodule:: blue_st_sdk.features.feature_proximity
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__

blue\_st\_sdk.features.feature\_proximity\_gesture module
---------------------------------------------------------

.. automodule:: blue_st_sdk.features.feature_proximity_gesture
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__

blue\_st\_sdk.features.feature\_stepper\_motor module
-----------------------------------------------------

.. automodule:: blue_st_sdk.features.feature_stepper_motor
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__

blue\_st\_sdk.features.feature\_switch module
---------------------------------------------

.. automodule:: blue_st_sdk.features.feature_switch
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__

blue\_st\_sdk.features.feature\_temperature module
--------------------------------------------------

.. automodule:: blue_st_sdk.features.feature_temperature
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__

blue\_st\_sdk.features.field module
-----------------------------------

.. automodule:: blue_st_sdk.features.field
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__


Module contents
---------------

.. automodule:: blue_st_sdk.features
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
